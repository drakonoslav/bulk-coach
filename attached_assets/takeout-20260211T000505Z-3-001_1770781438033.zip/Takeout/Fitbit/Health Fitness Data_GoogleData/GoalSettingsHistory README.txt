Goal Settings History

The GoalSettingsHistory file contains the settings history for the user goals.

Files Included:
----------

GoalSettingsHistory.csv

  name        - name of the goal
  objectives  - objectives of the goal containing the target value and the metric to measure
  schedule    - schedule of the goal, weekly or fixed datetime range
  status      - status of the goal, enabled or disabled
  update_time - time when the goal was updated with these settings
