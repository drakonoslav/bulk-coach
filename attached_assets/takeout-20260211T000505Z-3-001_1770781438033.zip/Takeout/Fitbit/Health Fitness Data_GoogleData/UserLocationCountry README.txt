User Location Country

The User Location Country data file contains the history of your location (country), which is used to supply content relevant to your location.

Files included:
----------

UserLocationCountry.csv

The data for User Location Country:

    value_time           - time at which the setting was input, timestamp
    setting_value        - user's location (country)
