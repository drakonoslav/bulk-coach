UserAppSettingData Export

The UserAppSetting data file contains user prerferences such as measurment units, height and weight system etc.

Files included:
----------

UserAppSettingData.csv

The data for User AppSettings

    preferred_workout_intensity_level              - the preferred workout intensity level of the user
    height_system                                  - the height system of the user
    weight_system                                  - the weight system of the user
    water_measurement_unit                         - the water measurement unit of the user
    glucose_measurement_unit                       - the glucose measurement unit of the user
    body_temperature_measurement_unit              - the body temperature measurement unit of the user
    pool_length                                    - the pool length of the user (e.g. 16 units)
    pool_length_measurement_unit                   - the pool length measurement unit of the user
    swim_unit                                      - the swim unit of the user
